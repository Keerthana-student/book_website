<?php
// Database connection settings
$servername = "localhost"; // Change if necessary
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$dbname = "register";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize form data
    $username = htmlspecialchars($_POST['username']);
    $email = htmlspecialchars($_POST['email']);
    $password = htmlspecialchars($_POST['password']);
    $confirm_password = htmlspecialchars($_POST['confirm-password']);
    $phone = htmlspecialchars($_POST['phone']);
    $sex = htmlspecialchars($_POST['sex']);
    $dob_day = htmlspecialchars($_POST['dob-day']);
    $dob_month = htmlspecialchars($_POST['dob-month']);
    $dob_year = htmlspecialchars($_POST['dob-year']);
    $languages = isset($_POST['languages']) ? $_POST['languages'] : [];
    $address = htmlspecialchars($_POST['address']);

    // Validate the password confirmation
    if ($password !== $confirm_password) {
        echo "Passwords do not match!";
        exit;
    }

    // Convert the date of birth to YYYY-MM-DD format
    $dob = "$dob_year-$dob_month-$dob_day";

    // Convert languages array to a comma-separated string
    $languages_known = implode(', ', $languages);

    // Hash the password before storing it
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO users (username, email, password, phone, sex, dob, languages, address) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssss", $username, $email, $hashed_password, $phone, $sex, $dob, $languages_known, $address);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Registration successful!";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    // If the form is not submitted, redirect back to the form page
    header("Location: index.html");
    exit;
}
?>
