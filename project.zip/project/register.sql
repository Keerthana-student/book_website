-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 28, 2024 at 09:30 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `register`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `sex` enum('male','female','other','') NOT NULL,
  `dob` date NOT NULL,
  `language` varchar(255) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`id`, `user_name`, `email`, `password`, `phone_number`, `sex`, `dob`, `language`, `address`) VALUES
(1, 'keerthi', 'keerthanav1910@gmail.com', '$2y$10$jh0sKWbqaZSTl1Hfjgt8w.co4XBJZyCrCn7ITVzpnzw4c0WE67zmy', '09342481144', 'female', '2007-12-16', 'telugu', 'pondy'),
(2, 'keerthi', 'keerthanav1910@gmail.com', '$2y$10$L5zqIWthvydZuiKLYaWRsOK3F.mmR/FZGY/sIS2D5Yz3AbFWddnf2', '09342481144', 'female', '2007-12-16', 'telugu', 'pondy'),
(3, 'jai', 'keerthanav1910@gmail.com', '$2y$10$m3RrxIXkQ83txszlObmRBuesMMdfxOIMGWoVYPtreT/oodmJd406u', '789456123', 'male', '2009-11-17', 'telugu', 'asdfgyrw'),
(4, 'keerthi', 'keerthanav1910@gmail.com', '$2y$10$qEns5b6YLY134WBbpIThueUJwHKf1MzQSPIggQylFHpUDRjK/sJ2W', '09342481144', 'male', '2006-12-18', 'telugu', 'pondy'),
(6, 'jaijai', 'jaijai2002@gmail.com', '$2y$10$mD.Ci4saj/y1ocvAj8oJL.Ofon2pMuzJ42y9WjdXawpBNca91PSW.', '6485963127', 'male', '2003-04-18', 'tamil', 'Velrampet');

-- --------------------------------------------------------

--
-- Table structure for table `form`
--

CREATE TABLE `form` (
  `id` int(11) NOT NULL,
  `user_name` int(11) NOT NULL,
  `email` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rform`
--

CREATE TABLE `rform` (
  `id` int(11) NOT NULL,
  `user_name` varchar(25) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` varchar(10) NOT NULL,
  `c_password` varchar(10) NOT NULL,
  `phone_number` varchar(10) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `dob` varchar(15) NOT NULL,
  `language` varchar(15) NOT NULL,
  `address` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rform`
--
ALTER TABLE `rform`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
