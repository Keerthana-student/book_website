<?php
session_start();
include("db.php");

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $username = $_POST['username'];
    $pass = $_POST['password'];

    $errors = [];

    if (empty($username)) {
        $errors[] = 'Username is required';
    }
    if (empty($pass)) {
        $errors[] = 'Password is required';
    }

    if (empty($errors)) {
        $query = "SELECT * FROM book WHERE user_name = ? LIMIT 1";
        $stmt = $con->prepare($query);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user_data = $result->fetch_assoc();

            if (password_verify($pass, $user_data['password'])) {
                $_SESSION['username'] = $username;
                header("Location: slog.html"); // Redirect to the home page
                exit();
            } else {
                $errors[] = 'Wrong username or password';
            }
        } else {
            $errors[] = 'Wrong username or password';
        }

        $stmt->close();
    }

    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo "<script type='text/javascript'> alert('$error');</script>";
        }
    }

    $con->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            font-family: "Poppins", sans-serif;
        }
        body {
            background-image: url('b3.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            background-repeat: no-repeat;
        }
        .box {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 90vh;
        }
        .container {
            width: 350px;
            display: flex;
            flex-direction: column;
            padding: 15px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
        }
        span {
            color: #73401a;
            font-size: small;
            display: flex;
            justify-content: center;
            padding: 10px 0;
        }
        header {
            color: #73401a;
            font-size: 30px;
            display: flex;
            justify-content: center;
            padding: 10px 0;
            font-family: "Imprint MT Shadow";
        }
        .input-field {
            display: flex;
            flex-direction: column;
            position: relative;
            margin-bottom: 15px;
        }
        .input {
            height: 45px;
            width: 100%;
            border: none;
            border-radius: 30px;
            color: #73401a;
            font-size: 15px;
            padding-left: 45px;
            background: rgba(255, 255, 255, 0.1);
            outline: none;
            font-family: "Book Antiqua";
        }
        i {
            position: absolute;
            top: 50%;
            left: 17px;
            transform: translateY(-50%);
            color: #73401a;
        }
        .error-message {
            color: red;
            font-size: 12px;
            display: block;
            position: absolute;
            bottom: -20px;
            left: 0;
        }
        ::-webkit-input-placeholder {
            color: #73401a;
        }
        .submit {
            border: none;
            border-radius: 30px;
            font-size: 15px;
            height: 45px;
            outline: none;
            width: 100%;
            color: black;
            background: #a37d4a;
            cursor: pointer;
            transition: 0.3s;
        }
        .submit:hover {
            box-shadow: 1px 5px 7px 1px rgba(0, 0, 0, 0.2);
        }
        .bottom {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            font-size: small;
            color: #f8e9e9;
            margin-top: 10px;
        }
        .left {
            display: flex;
        }
        label a {
            text-decoration: none;
            color: #e8e7f1;
        }
    </style>
    <title>Ludiflex | Login</title>
</head>
<body>
    <div class="box">
        <div class="container">
            <div class="top-header">
                <span>Have an account?</span>
                <header>LOGIN</header>
            </div>
            <form method="POST" action="login.php">
                <div class="input-field">
                    <input
                        type="text"
                        class="input"
                        placeholder="Username"
                        name="username"
                        value="<?php echo isset($username) ? htmlspecialchars($username) : ''; ?>"
                    />
                    <i class="fa-solid fa-user"></i>
                    <?php if (isset($errors) && in_array('Invalid username', $errors)) { ?>
                        <span class="error-message">Invalid username</span>
                    <?php } ?>
                </div>
                <div class="input-field">
                    <input
                        type="password"
                        class="input"
                        placeholder="Password"
                        name="password"
                    />
                    <i class="fa-solid fa-lock"></i>
                    <?php if (isset($errors) && in_array('Password is required', $errors)) { ?>
                        <span class="error-message">Password is required</span>
                    <?php } ?>
                    <?php if (isset($errors) && in_array('Wrong username or password', $errors)) { ?>
                        <span class="error-message">Wrong username or password</span>
                    <?php } ?>
                </div>
                <div class="input-field">
                    <input type="submit" class="submit" value="Login" />
                </div>
            </form>
        </div>
    </div>
</body>
</html>
