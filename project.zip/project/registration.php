<?php
session_start();
include("db.php");

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $username = $_POST['username'];
    $mail = $_POST['email'];
    $pass = $_POST['password'];
    $cpass = $_POST['confirm-password'];
    $cell = $_POST['phone'];
    $gender = $_POST['sex'];
    $dob_day = $_POST['dob-day'];
    $dob_month = $_POST['dob-month'];
    $dob_year = $_POST['dob-year'];
    $dob = "$dob_year-$dob_month-$dob_day";  // Correctly format the date
    $language = isset($_POST['languages']) ? implode(',', $_POST['languages']) : '';  // Join multiple selected languages with a comma
    $add = $_POST['address'];

    $errors = [];

    // Validate fields
    if (empty($username)) $errors[] = 'Username is required';
    if (empty($pass) || empty($cpass)) $errors[] = 'Password and Confirm Password are required';
    if ($pass !== $cpass) $errors[] = 'Passwords do not match';
    if (empty($mail) || !filter_var($mail, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required';
    if (empty($cell)) $errors[] = 'Phone number is required';
    if (empty($gender)) $errors[] = 'Gender is required';
    if (empty($dob_day) || empty($dob_month) || empty($dob_year)) $errors[] = 'Complete Date of Birth is required';
    if (empty($add)) $errors[] = 'Address is required';

    // Check if there are any validation errors
    if (empty($errors)) {
        // Hash the password before storing it
        $hashed_pass = password_hash($pass, PASSWORD_BCRYPT);

        // Use a prepared statement to prevent SQL injection
        $stmt = $con->prepare("INSERT INTO book (user_name, email, password, phone_number, sex, dob, language, address) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssss", $username, $mail, $hashed_pass, $cell, $gender, $dob, $language, $add);

        if ($stmt->execute()) {
            echo "<script type='text/javascript'> alert('Successfully Registered');</script>";
        } else {
            echo "<script type='text/javascript'> alert('Error: Could not execute query');</script>";
        }

        $stmt->close();
    } else {
        // Display errors
        foreach ($errors as $error) {
            echo "<script type='text/javascript'> alert('$error');</script>";
        }
    }
    $con->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Page</title>
    <style>
        body {
            background-image: url('as2.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-size: larger;
        }

        .container {
            background-color: rgba(0, 0, 0, 0.5);
            padding: 20px;
            width: 600px;
            color: #d29e48;
            font-family: 'Book Antiqua', serif;
            border-radius: 10px;
        }

        .container h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #d29e48;
            font-family: 'Sitka Small Semibold', serif;
        }

        .form-group {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 15px;
        }

        .form-group label {
            flex: 1;
            margin-right: 10px;
            font-weight: bold;
            white-space: nowrap;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            flex: 2;
            padding: 8px;
            border: 1px solid #673105;
            border-radius: 30px;
            background-color: #ba7c4a;
            color: aliceblue;
        }

        .form-group input[type="radio"],
        .form-group input[type="checkbox"] {
            flex: 0;
            margin-right: 10px;
        }

        .form-group .radio-group,
        .form-group .checkbox-group {
            flex: 2;
            display: flex;
            align-items: center;
        }

        .form-group .checkbox-group {
            flex-direction: row;
            flex-wrap: wrap;
        }

        .form-group .checkbox-group input,
        .form-group .checkbox-group label {
            margin-right: 10px;
        }

        .button-container {
            width: 100%;
            display: flex;
            justify-content: center;
        }

        .button-container button {
            width: 100%;
            padding: 10px;
            background-color: #673105;
            color: #d29e48;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            font-size: 20px;
            font-family: 'Book Antiqua', serif;
        }

        .button-container button:hover {
            background-color: #c57d43;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>REGISTER</h2><br>
        <form id="registrationForm"  method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="confirm-password">Confirm Password</label>
                <input type="password" id="confirm-password" name="confirm-password" required>
            </div>
            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="text" id="phone" name="phone" required>
            </div>
            <div class="form-group">
                <label>Sex</label>
                <div class="radio-group">
                    <input type="radio" id="male" name="sex" value="male" required>
                    <label for="male">Male</label>
                    <input type="radio" id="female" name="sex" value="female">
                    <label for="female">Female</label>
                    <input type="radio" id="other" name="sex" value="other">
                    <label for="other">Other</label>
                </div>
            </div>
            <div class="form-group">
                <label>Date of Birth</label>
                <select id="dob-day" name="dob-day" required>
                    <option value="">Day</option>
                    <?php for ($i = 1; $i <= 31; $i++) echo "<option value=\"$i\">$i</option>"; ?>
                </select>
                <select id="dob-month" name="dob-month" required>
                    <option value="">Month</option>
                    <?php for ($i = 1; $i <= 12; $i++) echo "<option value=\"$i\">$i</option>"; ?>
                </select>
                <select id="dob-year" name="dob-year" required>
                    <option value="">Year</option>
                    <?php 
                        $currentYear = date('Y');
                        for ($i = $currentYear; $i >= 1900; $i--) echo "<option value=\"$i\">$i</option>"; 
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label>Languages Known</label>
                <div class="checkbox-group">
                    <input type="checkbox" id="english" name="languages[]" value="english">
                    <label for="english">English</label>
                    <input type="checkbox" id="telugu" name="languages[]" value="telugu">
                    <label for="telugu">Telugu</label>
                    <input type="checkbox" id="hindi" name="languages[]" value="hindi">
                    <label for="hindi">Hindi</label>
                    <input type="checkbox" id="tamil" name="languages[]" value="tamil">
                    <label for="tamil">Tamil</label>
                </div>
            </div>
            <div class="form-group">
                <label for="address">Address</label>
                <textarea id="address" name="address" rows="4" required></textarea>
            </div>
            <div class="button-container">
                <button type="submit">Register</button>
            </div>
        </form>
    </div>
</body>

</html>
