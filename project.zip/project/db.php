<?php
$host = 'localhost'; // your database host
$user = 'root'; // your database username
$password = ''; // your database password
$dbname = 'register'; // your database name

$con = mysqli_connect($host, $user, $password, $dbname);

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
