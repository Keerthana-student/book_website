<?php

session_start();
$value = $_SESSION['rdate'];
echo $value;



?>